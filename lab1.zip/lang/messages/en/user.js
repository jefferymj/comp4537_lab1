const messages = {
    addNote: 'Add Note',
    removeNote: 'Remove',
    storedAt: 'Stored at:',
    updatedAt: 'Updated at:',
    noNotes: 'No notes available.',
};